import java.io.BufferedReader;
import java.io.FileReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

// Class to represent a person with a name and age
class Person {
  private String name;
  private int age;

  // Constructor to initialize a Person object
  Person(String name, int age) {
    this.name = name;
    this.age = age;
  }

  // Method to print person details into a file with the required format
  void printPerson(BufferedWriter writer) throws IOException {
    String describe = name + " is " + age + " years old.";
    writer.write(describe + "\n");
  }
}

// Main class for Project 0A
class AdeoshunA_Project0A_Main {
  public static void main(String args[]) throws IOException {
    // args[0] = input file name
    // args[1] = output file name

    // Create file reader to read input data
    BufferedReader reader = new BufferedReader(new FileReader(args[0]));

    // Create file writer to write program output
    BufferedWriter writer = new BufferedWriter(new FileWriter(args[1]));

    // First line of input contains number of people
    String line = reader.readLine();
    int numOfPeople = Integer.parseInt(line);

    // Array to hold Person objects
    Person people[] = new Person[numOfPeople];

    // Read each line, extract name and age, create Person object
    int index = 0;
    while (index < numOfPeople) {
      line = reader.readLine();
      String data[] = line.split(" "); // split line into name and age
      String name = data[0];
      int age = Integer.parseInt(data[1]);
      Person p = new Person(name, age);
      people[index++] = p; // add person to array
    }

    // Write header line before listing people
    writer.write("*** There are " + numOfPeople + " people ***\n");

    // Loop through array and write each person's details
    for (Person person : people) {
      person.printPerson(writer);
    }

    // Close both reader and writer streams
    reader.close();
    writer.close();
  }
}
